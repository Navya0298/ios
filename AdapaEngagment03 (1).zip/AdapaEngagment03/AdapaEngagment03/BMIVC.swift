//
//  BMIVC.swift
//  AdapaEngagment03
//
//  Created by Adapa,Venkata Rayudu on 4/6/23.
//

import UIKit

class BMIVC: UIViewController, UIPickerViewDelegate,UIPickerViewDataSource {
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
      return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == 0 {
            return 11
        }else{
            return 13
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        if component == 0 {
            return Feet[row]
        }else{
            return Inch[row]
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
           FeetSelected = Feet[pickerView.selectedRow(inComponent: 0)]
           InchSelected = Inch[pickerView.selectedRow(inComponent: 1)]
    }

    var Feet = [String]()
    var Inch = [String]()
    var FeetSelected : String = ""
    var InchSelected : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        heightPicker.delegate = self
        heightPicker.dataSource = self
        Feet.append("Feet")
        Inch.append("Inch")
        (1...10).forEach { Feet.append("\($0)") }
        (0...11).forEach { Inch.append("\($0)") }
    }
    
    
    @IBOutlet weak var ageTF: UITextField!
    @IBOutlet weak var weightTF: UITextField!
    @IBOutlet weak var heightPicker: UIPickerView!
    @IBOutlet weak var messageLBL: UILabel!
    
    
    @IBAction func onCalculate(_ sender: UIButton) {
        guard let wt = self.weightTF.text, !(wt.isEmpty), !(self.FeetSelected.isEmpty), !(self.InchSelected.isEmpty), let age = self.ageTF.text, !(age.isEmpty), self.FeetSelected != "Feet", self.InchSelected != "Inch"
        else{
            messageLBL.text = ""
            return
        }
        
        let Weight = (Double(self.weightTF.text!)! * 0.453592)
        let heightFeet = (Double(self.FeetSelected)! * 0.3048)
        let heightInch = (Double(self.InchSelected)! * 0.0254)
        let BMI = ((Weight) / pow((heightFeet + heightInch),2))
        messageLBL.text = "Your Body Mass Index is:\(String(format: "%.1f", BMI))"
        //print(FeetSelected + " " + InchSelected)
    }
    
    
    @IBAction func onReset(_ sender: UIButton) {
        FeetSelected = ""
        InchSelected = ""
        ageTF.text = ""
        weightTF.text = ""
        messageLBL.text = ""
        self.heightPicker.selectRow(0, inComponent: 0, animated: true)
        self.heightPicker.selectRow(0, inComponent: 1, animated: true)
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
