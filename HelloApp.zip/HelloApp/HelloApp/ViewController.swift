//
//  ViewController.swift
//  HelloApp
//
//  Created by Muttukuri,Navya on 1/24/23.
//

import UIKit

class ViewController: UIViewController {
   
    @IBOutlet weak var nameOutlet: UITextField!
    
    @IBOutlet weak var DispalyLabelOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

    @IBAction func ClickButton(_ sender: UIButton) {
        //Read the input and store it (assign it to a variable.)
        var input = nameOutlet.text!
        
        //Perform String interpolation "Hello, Name!" and assign it to display label
        DispalyLabelOutlet.text = "Hello, \(input)!"
    }
    
}

