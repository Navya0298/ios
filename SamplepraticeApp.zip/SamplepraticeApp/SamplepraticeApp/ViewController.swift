//
//  ViewController.swift
//  SamplepraticeApp
//
//  Created by Muttukuri,Navya on 1/26/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var course1: UITextField!
    
    @IBOutlet weak var course2: UITextField!
    
    @IBOutlet weak var DisplayLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
    
    @IBAction func buttonClicked(_ sender: UIButton) {
        //Read the course1 name and store it in a variable
        var input = course1.text!;
        //Read the course2 name and store it in a variable
        var input1 = course2.text!;
        //Perform string interpolation and assign it to display label(course1 - course2)
        DisplayLabel.text = "\(input) - \(input1)!"
    }
    

}

