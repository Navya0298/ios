//
//  ViewController.swift
//  Muttukuri_Assignment01
//
//  Created by Muttukuri,Navya on 1/26/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var firstNameOutlet: UITextField!
    
    @IBOutlet weak var lastNameOutlet: UITextField!
    
    @IBOutlet weak var yearOutlet: UITextField!
    
    @IBOutlet weak var fullNameLabel: UILabel!
    
    @IBOutlet weak var initialsLabel: UILabel!
    
    @IBOutlet weak var ageLabel: UILabel!
    
    
    @IBOutlet weak var Details: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func SubmitBTN(_ sender: UIButton) {
        //Read the input and store it (assign it to a variable)
        var fn = firstNameOutlet.text!;
        var Ln = lastNameOutlet.text!;
        // perform the action
        let Dob = Int(yearOutlet.text!)
        // getting the current year
        let d = Date()
        let c = Calendar.current
        let y = c.component(.year, from: d)
        // Perform the action of current year minus date of birth
        let a = y - Dob!
        // It will show the output after we click on submit button
        Details.text =  "Details"
        fullNameLabel.text = "Full Name : \(Ln) \(fn)"
        initialsLabel.text = "initials : \(Ln.first!) \(fn.first!)"
        ageLabel.text = "Age : \(a)";
    }
    @IBAction func ResetBTN(_ sender: UIButton) {
        // perform the action after we click on reset button
        firstNameOutlet.text = ""
        lastNameOutlet.text = ""
        yearOutlet.text = " "
        Details.text = ""
        fullNameLabel.text = ""
        initialsLabel.text = ""
        ageLabel.text = ""
    }
    

    
}

