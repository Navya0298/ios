//
//  ViewController.swift
//  UsernameAndPassword
//
//  Created by Muttukuri,Navya on 1/25/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Username: UITextField!
    
    
    @IBOutlet weak var Password: UITextField!
    
    
    @IBOutlet weak var SignAsUsername: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func Submitbutton(_ sender: UIButton) {
        var input = Username.text!
        var input1 = Password.text!
        SignAsUsername.text = "SigninAs,\(input)!"
        
    
    }
    
    

}

