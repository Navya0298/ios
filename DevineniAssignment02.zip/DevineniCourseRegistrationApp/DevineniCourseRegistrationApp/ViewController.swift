//
//  ViewController.swift
//  DevineniCourseRegistrationApp
//
//  Created by Devineni,Vasavi on 2/6/23.
//

import UIKit

class CourseRegistrationVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.messageLBL.text = ""
        self.messageLBL.numberOfLines = 0
        for cs in courseSWCH
        {
            cs.isOn = false
        }
    }
    
    @IBOutlet weak var firstNameTF: UITextField!
    
    @IBOutlet weak var lastNameTF: UITextField!
    
    @IBOutlet weak var messageLBL: UILabel!
    
    @IBOutlet var courseSWCH: [UISwitch]!
    
    @IBAction func onSubmit(_ sender: UIButton) {
        
        var msgArr = [String](), message: String = ""
        let fName = self.firstNameTF.text, lName = self.lastNameTF.text
        
        if(fName == "" || lName == ""){
            self.messageLBL.text = "Please enter your full name."
        }else if(courseSWCH.filter {$0.isOn}.count > 0){
            for cs in courseSWCH{
                if(cs.tag == 0 && cs.isOn){
                    msgArr.append("IOS")
                }
                if(cs.tag == 1 && cs.isOn){
                    msgArr.append("Patterns")
                }
                if(cs.tag == 2 && cs.isOn){
                    msgArr.append("Big Data")
                }
            }
            
            for index in msgArr.indices{
                if(index != 0){
                    message = message + ", "
                }
                message = message + msgArr[index]
            }
            self.messageLBL.text = "CONFIRMATION\n \(fName!),  \(lName!) has successfully enrolled in \(msgArr.count) course(s), namely, \(message)."
        }else{
            self.messageLBL.text = "Hi  \(fName!),  \(lName!)  please  select  the courses of your choice."
        }
    }
    
    
    @IBAction func onReset(_ sender: UIButton) {
        self.firstNameTF.text = ""
        self.lastNameTF.text = ""
        self.messageLBL.text=""
        for cs in courseSWCH
        {
            cs.isOn = false
        }
    }
    
    @IBAction func toggleCourse(_ sender: UISwitch) {
    }
}

